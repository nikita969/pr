/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pr1;

import com.mongodb.DBCursor;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import static pr1.Query.addUser;
import twitter4j.GeoLocation;
import twitter4j.Paging;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import pr1.Age_Gender_Prediction;
import static pr1.Age_Gender_Prediction.findGender;
import static pr1.Age_Gender_Prediction.loadGender;
import static pr1.Query.addToDataBase;
import static pr1.Query.tweetDB;


/**
 *
 * @author nikitaivancov
 */
public class TwitterClass {
    private static String  topic = null;
    public final ConfigurationBuilder configuration = new ConfigurationBuilder();
    public volatile static boolean flag=false;
    public volatile static boolean flag1=true;
   
    public static void gatheringTweets( String str) throws TwitterException, IOException{
        
        ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
        configurationBuilder.setDebugEnabled(true)
       .setOAuthConsumerKey("EmRxcWqQmx6FKTJgMMGw8uBNj")
       .setOAuthConsumerSecret("Q1agKp2hVgNdl8TaSLTzP6lab4gjTSqayC0u7juwTpHM47NPT6")
       .setOAuthAccessToken("849206934599344128-5fbEH2JAepOQEEfzns5HeOBORG1fyXC")
       .setOAuthAccessTokenSecret("kIhdacJp61DJXcK6pq1AdeTod4HfrUNoCtfBRXBKFNXVh");

        Twitter twitter = new TwitterFactory(configurationBuilder.build()).getInstance();
        Query query=null;
        if(str!=null)
        query = new Query(str);
        else
            query = new Query();
       
        int size = 0;
        query.setLang("en");
        int numberOfTweets = 99999;
        long lastID = Long.MAX_VALUE;
        ArrayList<Status> tweets = new ArrayList<>();
        while (flag == true) {
            flag1=false;
            if (numberOfTweets - size > 100) {
                query.setCount(100);
            } else {
                query.setCount(numberOfTweets - size);
            }            
            try {
                QueryResult result = twitter.search(query);
                tweets.addAll(result.getTweets());
                System.out.println("Gathered " + tweets.size() + " tweets" + "\n");
            } catch (TwitterException te) {
                System.out.println("Couldn't connect: " + te);
            }
            query.setMaxId(lastID - 1);
            size += tweets.size();
            for (int i = 0; i < tweets.size() && flag == true; i++) {
                System.out.println(tweets.get(i));
                Status t = (Status) tweets.get(i);
                gatherByUserId(t);
            }
            tweets.removeAll(tweets);
            query.setMaxId(lastID - 1); 
        }
             flag1=true;
    } 
      
    public static void gatherByUserId(Status st) throws TwitterException, IOException {
        ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
        configurationBuilder.setDebugEnabled(true)
        .setOAuthConsumerKey("EmRxcWqQmx6FKTJgMMGw8uBNj")
        .setOAuthConsumerSecret("Q1agKp2hVgNdl8TaSLTzP6lab4gjTSqayC0u7juwTpHM47NPT6")
        .setOAuthAccessToken("849206934599344128-5fbEH2JAepOQEEfzns5HeOBORG1fyXC")
        .setOAuthAccessTokenSecret("kIhdacJp61DJXcK6pq1AdeTod4HfrUNoCtfBRXBKFNXVh");
        Twitter twitter = new TwitterFactory(configurationBuilder.build()).getInstance();
        Paging page = new Paging(1, 500);
        List<Status> statuses = twitter.getUserTimeline(st.getUser().getScreenName(), page);
        if (statuses.size() > 20) {
            addToDataBase(statuses);
        }
        statuses.removeAll(statuses);
        System.out.println("done");
    }
}
