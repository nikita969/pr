/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pr1;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static pr1.TwitterClass.gatheringTweets;
import twitter4j.TwitterException;

/**
 *
 * @author nikitaivancov
 */
public class MyThread extends Thread{
  
   
    private static String topic;
    public  MyThread(){
        
    }
    
     public static void setTopic(String str){
        topic=str;
    }
    
    public void run(){
        
        try {   
            gatheringTweets(topic);
        } catch (TwitterException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   
    
}
